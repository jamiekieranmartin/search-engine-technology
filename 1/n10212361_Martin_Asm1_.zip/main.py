# Jamie Martin
# N10212361
from BowDocCollection import BowDocCollection
from os.path import isfile, join
from os import listdir


def write_to_file(file, body):
    """
    Opens file, writes body to it, and then close file
    """
    file = open(join('./output', file), 'w')
    file.write(body)
    file.close()


if __name__ == "__main__":
    # --- SETUP ---

    # Get stop words list
    file = open('./common-english-words.txt', 'r')
    stopWords = file.read().split(',')
    file.close()

    # Get files list for parsing
    _dir = './input'
    files = [join(_dir, f) for f in listdir(_dir) if isfile(join(_dir, f))]

    # --- Q1 ---

    print('\n--- Q1 ---\n')

    collection = BowDocCollection(files, stopWords)
    collection_info = collection.displayDocInfo()
    write_to_file('jamie_martin_Q1.txt', collection_info)

    # --- Q2_1 ---

    print('\n--- Q2_1 ---\n')

    df = collection.calculate_df()
    
    body = 'There are {docCount} documents in this data set and contains {terms} terms.\n'.format(docCount=len(collection.collection), terms=len(df))
    for term, count in df.items():
        body += '{term}: {count}\n'.format(term=term, count=count)

    print(body)
    write_to_file('jamie_martin_Q2_1.txt', body)

    # --- Q2_2 ---

    print('\n--- Q2_2 ---\n')

    tfidf = collection.calculate_tfidf() 

    body = ''
    for id, doc_tfidf in tfidf.items():
        body += 'Document {docId} contains {terms} terms.\n'.format(docId=id, terms=len(collection.collection[id].terms))
        for term, value in doc_tfidf.items():
            body += '{term}: {value}\n'.format(term=term, value=value)
        body += '\n'

    print(body)  
    write_to_file('jamie_martin_Q2_2.txt', body)
   
    # --- Q3_2 ---

    print('\n--- Q3_2 ---\n')

    body = collection.docLen()
    print(body)
    write_to_file("jamie_martin_Q3_2.txt", body)

    print("\n--- Q3_3 ---\n")

    query = ["British", "fashion"]
    body = collection.query(query)
    print(body)
    write_to_file("jamie_martin_Q3_3.txt", body)
